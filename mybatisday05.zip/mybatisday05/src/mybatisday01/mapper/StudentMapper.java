package mybatisday01.mapper;


import mybatisday01.domain.Student;

public interface StudentMapper {
	
	public void addStudents(Student lists);
	
}
