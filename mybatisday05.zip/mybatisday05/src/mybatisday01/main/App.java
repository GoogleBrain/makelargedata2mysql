package mybatisday01.main;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import mybatisday01.domain.Student;
import mybatisday01.mapper.StudentMapper;

public class App {
	public static void main(String[] args) throws IOException {
		String name = "mybatis-config.xml";
		InputStream resourceAsStream = Resources.getResourceAsStream(name);

		SqlSessionFactory build = new SqlSessionFactoryBuilder().build(resourceAsStream);
		/**
		 * ����������ʽ�������ݵĲ��롣
		 */
		SqlSession openSession = build.openSession(ExecutorType.BATCH);
		StudentMapper selectOne = openSession.getMapper(StudentMapper.class);
		for(int i=0;i<100000000;i++){
			Student stu = new Student();
			stu.setLastName("LastName"+i);
			stu.setEmail("email"+i);
			stu.setGender(1);
			stu.setCreatetime(new Date()+"");
            stu.setC1("C1"+i);
            stu.setC2("C2"+i);
            stu.setC3("C3"+i);
            stu.setC4("C4"+i);
            stu.setC5("C4"+i);
            stu.setC6("C6"+i);
            stu.setC7("C7"+i);
            stu.setC8("C8"+i);
            stu.setC9("C9"+i);
            stu.setC10("C10"+i);
            stu.setC11("C11"+i);
            stu.setC12("C12"+i);
            stu.setC13("C13"+i);
            stu.setC14("C14"+i);
            stu.setC15("C15"+i);
            stu.setC16("C16"+i);
            stu.setC17("C17"+i);
            stu.setC18("C18"+i);
			selectOne.addStudents(stu);
			
			if(i%5000==0){
				openSession.commit();
				System.out.println(">>>>��ǰֵ:"+i+new Date());
			}
		}
		openSession.commit();
		openSession.close();
	}
}
